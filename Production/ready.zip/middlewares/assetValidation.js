const assetValidation = (req, res, next)=>{

    
}